from auto_ml_c import Feature_structure as fs
print("hello")